CREATE DATABASE XOXO;
USE XOXO;

CREATE TABLE class (
    id INT,
    name VARCHAR(50),
    age INT,
    course VARCHAR(50),
    marks INT
);

INSERT INTO class VALUES
(1, "rahul", 20, "python", 88),
(2, "namit", 21, "dsa", 97),
(3, "nikhil", 20, "python", 67),
(4, "ram", 50, "dsa", 99);

SELECT * FROM class;

SELECT course, AVG(marks)
FROM class
GROUP BY course;

SELECT course, MAX(marks)
FROM class
GROUP BY course;

SELECT MAX(marks)
FROM class
WHERE course = "python";
