# Day 1 – MySQL Basics

This repository contains my Day 1 SQL practice using MySQL.

## Database
CREATE DATABASE XOXO;
USE XOXO;

## Table
CREATE TABLE class (
    id INT,
    name VARCHAR(50),
    age INT,
    course VARCHAR(50),
    marks INT
);

## Insert Data
INSERT INTO class VALUES
(1, "rahul", 20, "python", 88),
(2, "namit", 21, "dsa", 97),
(3, "nikhil", 20, "python", 67),
(4, "ram", 50, "dsa", 99);
